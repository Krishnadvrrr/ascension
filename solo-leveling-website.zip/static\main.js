let currentHunterId = 1;
let currentHunterName = "Sung Jin-Woo";
const BASE_URL = window.location.origin;

// 1. Array of your custom anime wallpapers (pic1 to pic12)
const backgroundImages = [
  "/static/images/pic1.jpeg",
  "/static/images/pic2.jpeg",
  "/static/images/pic3.jpeg",
  "/static/images/pic4.jpeg",
  "/static/images/pic5.jpeg",
  "/static/images/pic6.jpeg",
  "/static/images/pic7.jpeg",
  "/static/images/pic8.jpeg",
  "/static/images/pic9.jpeg",
  "/static/images/pic10.jpeg",
  "/static/images/pic12.jpeg"
];

let bgIndex = 0;
let isBufferActive = false;

// 2. Preload & smoothly crossfade wallpapers every 4.5 seconds
function initBackgroundSlideshow() {
  const bgMain = document.getElementById("bg-slideshow");
  const bgBuffer = document.getElementById("bg-slideshow-buffer");
  if (!bgMain || backgroundImages.length === 0) return;

  // Preload all 8 images
  backgroundImages.forEach(src => {
    const img = new Image();
    img.src = src;
  });

  // Set initial image
  bgMain.style.backgroundImage = `url('${backgroundImages[0]}')`;

  if (!bgBuffer) {
    // Single container fallback
    setInterval(() => {
      bgIndex = (bgIndex + 1) % backgroundImages.length;
      bgMain.style.backgroundImage = `url('${backgroundImages[bgIndex]}')`;
    }, 4000);
    return;
  }

  // Cross-fading between main and buffer containers
  setInterval(() => {
    bgIndex = (bgIndex + 1) % backgroundImages.length;
    const nextImgUrl = `url('${backgroundImages[bgIndex]}')`;

    if (!isBufferActive) {
      bgBuffer.style.backgroundImage = nextImgUrl;
      bgBuffer.style.opacity = "1";
      bgMain.style.opacity = "0";
    } else {
      bgMain.style.backgroundImage = nextImgUrl;
      bgMain.style.opacity = "1";
      bgBuffer.style.opacity = "0";
    }
    isBufferActive = !isBufferActive;
  }, 4500);
}

// 3. Futuristic Web Audio Synthesizer (No external sound files required)
function playSystemSound(type = "login") {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    if (type === "login") {
      // Deep sub-bass resonance + high-tech ascending arpeggio
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = "sawtooth";
      osc1.frequency.setValueAtTime(65, ctx.currentTime);
      osc1.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.3);
      gain1.gain.setValueAtTime(0.35, ctx.currentTime);
      gain1.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start();
      osc1.stop(ctx.currentTime + 0.9);

      // High cyber chime
      const notes = [440, 660, 880, 1320];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.08);
        gain.gain.setValueAtTime(0.18, ctx.currentTime + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.08 + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.08);
        osc.stop(ctx.currentTime + i * 0.08 + 0.5);
      });
    } else if (type === "quest") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } else if (type === "levelup") {
      [330, 440, 554.37, 659.25, 880].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);
        gain.gain.setValueAtTime(0.25, ctx.currentTime + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.1);
        osc.stop(ctx.currentTime + idx * 0.1 + 0.6);
      });
    }
  } catch (e) {
    // Audio contexts may be blocked before interaction, handled gracefully
  }
}

// 4. Hunter Authentication Handler
async function handleHunterAuth(event) {
  event.preventDefault();
  const usernameInput = document.getElementById("login-username");
  const passwordInput = document.getElementById("login-password");
  const feedbackElem = document.getElementById("login-feedback");
  const submitBtn = document.getElementById("btn-login");

  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  if (!username) return;

  submitBtn.disabled = true;
  submitBtn.querySelector(".btn-text").innerText = "SYNCHRONIZING...";

  try {
    const res = await fetch(`${BASE_URL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (!res.ok) {
      if (feedbackElem) {
        feedbackElem.className = "login-feedback error";
        feedbackElem.innerText = `⚠ ${data.error || "Access Denied: Verification failed."}`;
        feedbackElem.classList.remove("hidden");
      }
      submitBtn.disabled = false;
      submitBtn.querySelector(".btn-text").innerText = "AUTHENTICATE & CONNECT";
      return;
    }

    // Success
    const character = data.character || {};
    currentHunterId = character.id || 1;
    currentHunterName = character.name || username;

    localStorage.setItem("hunter_profile", JSON.stringify({
      id: currentHunterId,
      name: currentHunterName,
      level: character.level || 1
    }));

    if (feedbackElem) {
      feedbackElem.className = "login-feedback success";
      feedbackElem.innerText = `✔ [SYSTEM CONFIRMED]: Welcome back, Hunter ${currentHunterName}.`;
      feedbackElem.classList.remove("hidden");
    }

    // Trigger the 3D text animation sequence
    setTimeout(() => {
      trigger3DWelcomeSequence(currentHunterName);
    }, 400);

  } catch (err) {
    console.error("Auth request error:", err);
    // Fallback in case server isn't reached
    currentHunterName = username;
    trigger3DWelcomeSequence(username);
  } finally {
    submitBtn.disabled = false;
    submitBtn.querySelector(".btn-text").innerText = "AUTHENTICATE & CONNECT";
  }
}

// Quick Register helper for testing
function quickRegisterDemo() {
  const usernameInput = document.getElementById("login-username");
  const passwordInput = document.getElementById("login-password");
  const newCodename = prompt("Enter new Hunter Codename:", "Sung Jin-Woo");
  if (newCodename) {
    usernameInput.value = newCodename;
    passwordInput.value = "hunter123";
    document.getElementById("login-form").requestSubmit();
  }
}

// 5. Toggle Full Wallpaper View (Hide/Show UI)
function toggleInterfaceVisibility() {
  const isHidden = document.body.classList.toggle("ui-hidden");
  const eyeButtons = document.querySelectorAll(".eye-toggle-btn");
  eyeButtons.forEach(btn => {
    btn.innerText = isHidden ? "👁 SHOW UI" : "👁 HIDE UI";
  });
}

// 6. Cinematic Opening Gate Transition + 3D Text Animation: "WELCOME BACK, SIR"
function trigger3DWelcomeSequence(hunterName) {
  const loginGateway = document.getElementById("login-gateway");
  const gateOverlay = document.getElementById("opening-gate-overlay");
  const stage3D = document.getElementById("cinematic-3d-stage");
  const hudContainer = document.getElementById("hud-container");
  const saluteTag = document.getElementById("cinematic-hunter-name");
  const text3D = document.querySelector(".text-3d-massive");

  // Play synthetic system resonance audio
  playSystemSound("login");

  // Step 1: Hide login gateway
  if (loginGateway) {
    loginGateway.classList.add("hidden");
  }

  // Step 2: Trigger Aperture Shutter Gate Opening Transition
  if (gateOverlay) {
    gateOverlay.classList.remove("hidden", "gate-open");
    // Trigger CSS reflow then animate gate opening
    gateOverlay.offsetHeight;
    setTimeout(() => {
      gateOverlay.classList.add("gate-open");
    }, 50);
  }

  // Step 3: Update hunter name in 3D scene
  if (saluteTag) {
    saluteTag.innerText = `HUNTER // ${hunterName.toUpperCase()}`;
  }

  // Step 4: Re-trigger CSS animation on the 3D element
  if (text3D) {
    text3D.style.animation = "none";
    text3D.offsetHeight; // trigger reflow
    text3D.style.animation = "welcome3dCinema 2.4s cubic-bezier(0.16, 1, 0.3, 1) forwards";
  }

  // Step 5: Show 3D cinematic stage
  if (stage3D) {
    stage3D.classList.remove("hidden");
    stage3D.style.opacity = "1";
  }

  // Step 6: After 2.6s, dissolve 3D stage & gate, then slide-in Split HUD Wings
  setTimeout(() => {
    if (stage3D) {
      stage3D.style.transition = "opacity 0.7s ease-out";
      stage3D.style.opacity = "0";
      
      setTimeout(() => {
        stage3D.classList.add("hidden");
        if (gateOverlay) gateOverlay.classList.add("hidden");

        // Reveal Split Hanging Wings (they slide in from perimeter edges!)
        if (hudContainer) {
          hudContainer.classList.remove("hidden");
          applyProfile({ name: currentHunterName });
          loadCharacterData();
          loadTasks();
        }
      }, 700);
    }
  }, 2600);
}

// 7. Logout / Re-enter Gateway
function logoutHunter() {
  const loginGateway = document.getElementById("login-gateway");
  const hudContainer = document.getElementById("hud-container");
  const feedbackElem = document.getElementById("login-feedback");

  document.body.classList.remove("ui-hidden");
  if (hudContainer) hudContainer.classList.add("hidden");
  if (feedbackElem) feedbackElem.classList.add("hidden");
  if (loginGateway) {
    loginGateway.classList.remove("hidden");
    loginGateway.style.opacity = "1";
  }
}

// 7. Apply Profile info to HUD
function applyProfile(profile) {
  const greetingElem = document.getElementById("player-greeting");
  const nameElem = document.getElementById("player-name");
  const goalElem = document.getElementById("display-goal");

  const upperName = (profile.name || currentHunterName).toUpperCase();
  if (greetingElem) greetingElem.innerText = `WELCOME BACK, SIR`;
  if (nameElem) nameElem.innerText = upperName;
  if (goalElem) goalElem.innerText = "SHADOW MONARCH";
}

// 8. Load Character Stats from SQLite
async function loadCharacterData() {
  try {
    const res = await fetch(`${BASE_URL}/character/${currentHunterId}`);
    if (!res.ok) return;
    const data = await res.json();
    const char = data.character || data;

    const levelElem = document.getElementById("player-level");
    if (levelElem) {
      levelElem.innerText = char.level < 10 ? `0${char.level}` : char.level;
    }

    if (document.getElementById("stat-str")) document.getElementById("stat-str").innerText = char.strength || 10;
    if (document.getElementById("stat-vit")) document.getElementById("stat-vit").innerText = char.discipline || 10;
    if (document.getElementById("stat-agi")) document.getElementById("stat-agi").innerText = char.focus || 10;
    if (document.getElementById("stat-end")) document.getElementById("stat-end").innerText = char.endurance || 10;

    updateXPBar(char.current_xp, char.xp_for_next_level);
    updateRank(char.level);
  } catch (err) {
    console.error("Error loading character data:", err);
  }
}

// Default Solo Leveling Quests if database has no tasks yet
const defaultQuests = [
  { id: "def-1", name: "[DAILY QUEST] 100 Push-ups [0/100]", area: "fitness", difficulty: "medium", xp_reward: 25 },
  { id: "def-2", name: "[DAILY QUEST] 100 Sit-ups [0/100]", area: "fitness", difficulty: "medium", xp_reward: 25 },
  { id: "def-3", name: "[DAILY QUEST] 100 Squats [0/100]", area: "fitness", difficulty: "medium", xp_reward: 25 },
  { id: "def-4", name: "[DAILY QUEST] 10km Running [0/10km]", area: "fitness", difficulty: "hard", xp_reward: 50 }
];

// 9. Load Tasks from SQLite with fallback to default Daily Quests
async function loadTasks() {
  const taskList = document.getElementById("task-list");
  if (!taskList) return;

  try {
    const res = await fetch(`${BASE_URL}/tasks/${currentHunterId}`);
    let tasks = [];
    if (res.ok) {
      const data = await res.json();
      tasks = data.tasks || [];
    }

    taskList.innerHTML = "";

    // If no tasks exist for this character, render the default Solo Leveling daily quests
    const displayTasks = tasks.length > 0 ? tasks : defaultQuests;

    displayTasks.forEach(task => {
      const li = document.createElement("li");
      li.className = "task-item";
      li.innerHTML = `
        <label class="checkbox-container">
          <input 
            type="checkbox" 
            data-task-id="${task.id || ''}" 
            data-task-name="${task.name || task.description || 'Daily Quest'}"
            data-area="${task.area || 'fitness'}" 
            data-difficulty="${task.difficulty || 'medium'}"
            data-xp="${task.xp_reward || 25}"
            onchange="completeTask(this)" 
            ${task.completed ? 'checked disabled' : ''} 
          />
          <span class="custom-check"></span>
          <span class="task-name" style="${task.completed ? 'text-decoration: line-through; opacity: 0.5;' : ''}">
            ${task.name || task.description || 'Daily Quest Objective'}
          </span>
        </label>
        <span class="task-reward">+${task.xp_reward || 25} XP</span>
      `;
      taskList.appendChild(li);
    });

  } catch (err) {
    console.error("Error loading tasks:", err);
  }
}

// 10. Complete Task Handler
async function completeTask(checkbox) {
  if (!checkbox.checked) return;

  const taskName = checkbox.dataset.taskName || checkbox.parentElement.querySelector(".task-name").innerText.trim();
  const area = checkbox.dataset.area || "fitness";
  const difficulty = checkbox.dataset.difficulty || "medium";

  // Play quest sound
  playSystemSound("quest");

  try {
    const res = await fetch(`${BASE_URL}/log-task`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        character_id: currentHunterId,
        name: taskName,
        area: area,
        description: taskName,
        difficulty: difficulty
      })
    });

    const result = await res.json();
    checkbox.disabled = true;
    checkbox.parentElement.querySelector(".task-name").style.textDecoration = "line-through";
    checkbox.parentElement.querySelector(".task-name").style.opacity = "0.5";

    await loadCharacterData();

    if (result.level_up) {
      playSystemSound("levelup");
      alert(`⚡ [SYSTEM NOTICE] LEVEL UP! You have reached Level ${result.new_level}! All attributes boosted.`);
    }
  } catch (err) {
    console.error("Failed to log task:", err);
  }
}

// 11. Custom Quest Form Handling
function openCustomQuestModal() {
  const modal = document.getElementById("add-quest-modal");
  if (modal) modal.classList.remove("hidden");
}

function closeCustomQuestModal() {
  const modal = document.getElementById("add-quest-modal");
  if (modal) modal.classList.add("hidden");
}

async function submitCustomQuest(event) {
  event.preventDefault();
  const name = document.getElementById("custom-task-name").value.trim();
  const area = document.getElementById("custom-task-area").value;
  const difficulty = document.getElementById("custom-task-difficulty").value;

  if (!name) return;

  try {
    const res = await fetch(`${BASE_URL}/log-task`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        character_id: currentHunterId,
        name: name,
        area: area,
        description: name,
        difficulty: difficulty
      })
    });

    const result = await res.json();
    closeCustomQuestModal();
    document.getElementById("custom-task-form").reset();
    playSystemSound("quest");

    await loadCharacterData();
    await loadTasks();

    if (result.level_up) {
      playSystemSound("levelup");
      alert(`⚡ [SYSTEM NOTICE] LEVEL UP! You have reached Level ${result.new_level}!`);
    }
  } catch (err) {
    console.error("Error submitting custom task:", err);
  }
}

// 12. XP Bar & Rank Updates
function updateXPBar(current, needed) {
  const cur = current || 0;
  const req = needed || 100;
  const percentage = Math.min((cur / req) * 100, 100);
  const xpFill = document.getElementById("xp-fill");
  const xpText = document.getElementById("xp-text");
  
  if (xpFill) xpFill.style.width = `${percentage}%`;
  if (xpText) xpText.innerText = `${cur} / ${req} XP`;
}

function updateRank(level) {
  const rankElem = document.getElementById("player-rank");
  if (!rankElem) return;
  if (level >= 50) rankElem.innerText = "S-RANK HUNTER (SHADOW MONARCH)";
  else if (level >= 40) rankElem.innerText = "A-RANK HUNTER";
  else if (level >= 30) rankElem.innerText = "B-RANK HUNTER";
  else if (level >= 20) rankElem.innerText = "C-RANK HUNTER";
  else if (level >= 10) rankElem.innerText = "D-RANK HUNTER";
  else rankElem.innerText = "E-RANK HUNTER";
}

// 13. DOM Ready Initialization
document.addEventListener("DOMContentLoaded", () => {
  initBackgroundSlideshow();

  // Check if hunter is cached
  const savedProfile = JSON.parse(localStorage.getItem("hunter_profile"));
  if (savedProfile && savedProfile.name) {
    const usernameInput = document.getElementById("login-username");
    if (usernameInput) usernameInput.value = savedProfile.name;
    currentHunterId = savedProfile.id || 1;
    currentHunterName = savedProfile.name;
  }
});