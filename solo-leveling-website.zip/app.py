from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///discipline_tracker.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ========================
# DATABASE MODELS
# ========================

class Character(db.Model):
    """User's character/profile"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(128), default='hunter123')
    level = db.Column(db.Integer, default=1)
    total_xp = db.Column(db.Integer, default=0)
    current_xp = db.Column(db.Integer, default=0)
    xp_for_next_level = db.Column(db.Integer, default=100)  # XP needed to level up
    
    # Stats
    discipline = db.Column(db.Integer, default=10)
    focus = db.Column(db.Integer, default=10)
    strength = db.Column(db.Integer, default=10)
    endurance = db.Column(db.Integer, default=10)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    tasks = db.relationship('Task', backref='character', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'level': self.level,
            'total_xp': self.total_xp,
            'current_xp': self.current_xp,
            'xp_for_next_level': self.xp_for_next_level,
            'xp_progress': f"{self.current_xp}/{self.xp_for_next_level}",
            'stats': {
                'discipline': self.discipline,
                'focus': self.focus,
                'strength': self.strength,
                'endurance': self.endurance
            },
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class Task(db.Model):
    """Fitness/life tasks"""
    id = db.Column(db.Integer, primary_key=True)
    character_id = db.Column(db.Integer, db.ForeignKey('character.id'), nullable=False)
    
    name = db.Column(db.String(200), nullable=False)
    area = db.Column(db.String(50), nullable=False)  # fitness, academics, hobbies, etc.
    description = db.Column(db.Text)
    difficulty = db.Column(db.String(20), default='medium')  # easy, medium, hard
    xp_reward = db.Column(db.Integer, default=10)
    
    completed_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'area': self.area,
            'description': self.description,
            'difficulty': self.difficulty,
            'xp_reward': self.xp_reward,
            'completed_at': self.completed_at.strftime('%Y-%m-%d %H:%M:%S')
        }


# ========================
# ROUTES
# ========================

@app.route('/api')
def api_info():
    return jsonify({
        'message': 'Welcome to Discipline Leveling System! 🚀',
        'endpoints': {
            'create_character': 'POST /create-character',
            'get_character': 'GET /character/<id>',
            'log_task': 'POST /log-task',
            'get_all_tasks': 'GET /tasks/<character_id>',
            'get_stats': 'GET /stats/<character_id>'
        }
    })


@app.route('/login', methods=['POST'])
def login():
    """Authenticate or awaken a Hunter profile"""
    data = request.json or {}
    username = (data.get('username') or data.get('name') or '').strip()
    password = (data.get('password') or '').strip()
    
    if not username:
        return jsonify({'error': 'Hunter ID / Name is required'}), 400
    
    # Check if character exists (case-insensitive)
    character = Character.query.filter(db.func.lower(Character.name) == username.lower()).first()
    
    if not character:
        # Auto-create character if first time logging in
        character = Character(name=username, password=password if password else 'hunter123')
        db.session.add(character)
        db.session.commit()
        return jsonify({
            'message': 'System awakened! New Hunter registered.',
            'character': character.to_dict(),
            'is_new': True
        }), 200
    
    # Check password if configured
    if password and character.password and character.password != password:
        return jsonify({'error': 'Invalid Hunter passcode. Access denied.'}), 401
    
    return jsonify({
        'message': 'Access granted. Welcome back, Hunter.',
        'character': character.to_dict()
    }), 200


@app.route('/register', methods=['POST'])
def register():
    """Register a new hunter codename"""
    data = request.json or {}
    name = (data.get('name') or data.get('username') or '').strip()
    password = (data.get('password') or 'hunter123').strip()
    
    if not name:
        return jsonify({'error': 'Hunter Codename is required'}), 400
    
    existing = Character.query.filter(db.func.lower(Character.name) == name.lower()).first()
    if existing:
        return jsonify({'error': 'Hunter Codename already registered'}), 400
    
    character = Character(name=name, password=password)
    db.session.add(character)
    db.session.commit()
    
    return jsonify({
        'message': 'Hunter Awakening Protocol Complete!',
        'character': character.to_dict()
    }), 201


@app.route('/create-character', methods=['POST'])
def create_character():
    """Create a new character"""
    data = request.json
    name = data.get('name')
    
    if not name:
        return jsonify({'error': 'Name is required'}), 400
    
    # Check if character already exists
    existing = Character.query.filter_by(name=name).first()
    if existing:
        return jsonify({'error': 'Character already exists'}), 400
    
    # Create new character
    character = Character(name=name)
    db.session.add(character)
    db.session.commit()
    
    return jsonify({
        'message': 'Character created!',
        'character': character.to_dict()
    }), 201


@app.route('/character/<int:character_id>', methods=['GET'])
def get_character(character_id):
    """Get character details"""
    character = Character.query.get(character_id)
    
    if not character:
        return jsonify({'error': 'Character not found'}), 404
    
    return jsonify(character.to_dict())


@app.route('/log-task', methods=['POST'])
def log_task():
    """Log a task and gain XP"""
    data = request.json or {}
    character_id = data.get('character_id') or 1
    name = data.get('name') or data.get('title') or data.get('description') or 'Daily Quest Objective'
    area = data.get('area') or data.get('category') or 'fitness'
    description = data.get('description') or name
    difficulty = data.get('difficulty', 'medium')
    
    # Find character
    character = Character.query.get(character_id)
    if not character:
        # Fallback to first character in DB if character_id not found
        character = Character.query.first()
        if not character:
            character = Character(name="Sung Jin-Woo")
            db.session.add(character)
            db.session.commit()
        character_id = character.id
    
    # Calculate XP based on difficulty
    xp_map = {'easy': 10, 'medium': 25, 'hard': 50}
    xp_reward = xp_map.get(difficulty, 25)
    
    # Create task
    task = Task(
        character_id=character_id,
        name=name,
        area=area,
        description=description,
        difficulty=difficulty,
        xp_reward=xp_reward
    )
    db.session.add(task)
    
    # Update character XP
    character.current_xp += xp_reward
    character.total_xp += xp_reward
    
    # Check for level up
    level_up = False
    while character.current_xp >= character.xp_for_next_level:
        character.current_xp -= character.xp_for_next_level
        character.level += 1
        
        # Increase stats on level up
        character.discipline += 2
        character.focus += 1
        character.strength += 1
        character.endurance += 1
        
        # Increase XP requirement for next level
        character.xp_for_next_level = int(character.xp_for_next_level * 1.1)
        level_up = True
    
    db.session.commit()
    
    response = {
        'message': 'Task logged successfully!',
        'xp_gained': xp_reward,
        'character': character.to_dict()
    }
    
    if level_up:
        response['level_up'] = True
        response['new_level'] = character.level
    
    return jsonify(response), 201


@app.route('/tasks/<int:character_id>', methods=['GET'])
def get_tasks(character_id):
    """Get all tasks for a character"""
    character = Character.query.get(character_id)
    
    if not character:
        return jsonify({'error': 'Character not found'}), 404
    
    tasks = Task.query.filter_by(character_id=character_id).order_by(Task.completed_at.desc()).all()
    
    return jsonify({
        'character_name': character.name,
        'total_tasks': len(tasks),
        'tasks': [task.to_dict() for task in tasks]
    })


@app.route('/stats/<int:character_id>', methods=['GET'])
def get_stats(character_id):
    """Get character stats and progress"""
    character = Character.query.get(character_id)
    
    if not character:
        return jsonify({'error': 'Character not found'}), 404
    
    # Get task counts by area
    all_tasks = Task.query.filter_by(character_id=character_id).all()
    tasks_by_area = {}
    for task in all_tasks:
        if task.area not in tasks_by_area:
            tasks_by_area[task.area] = 0
        tasks_by_area[task.area] += 1
    
    return jsonify({
        'character': character.to_dict(),
        'tasks_by_area': tasks_by_area,
        'total_tasks_completed': len(all_tasks)
    })


# Create database tables and ensure password column exists
with app.app_context():
    db.create_all()
    try:
        from sqlalchemy import text
        with db.engine.connect() as conn:
            conn.execute(text("ALTER TABLE character ADD COLUMN password VARCHAR(128) DEFAULT 'hunter123'"))
            conn.commit()
    except Exception:
        # Column already exists
        pass

    # Ensure at least one default character exists
    if not Character.query.first():
        default_char = Character(name="Sung Jin-Woo", password="hunter123")
        db.session.add(default_char)
        db.session.commit()


@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
